"""Validation and review helpers for financial data pipelines."""

